<?php $__env->startSection("content"); ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="text-secondary">
                        Users
                    </div>
                    <div class="h4">
                        <?php echo e(number_format(\App\Models\User::count())); ?>

                    </div>
                </div>
            </div>
        </div>


        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="text-secondary">
                        Bookings
                    </div>
                    <div class="h4">
                        <?php echo e(number_format(\App\Models\Booking::count())); ?>

                    </div>
                </div>
            </div>
        </div>


      </div>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tour_api\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>