<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">

            <div class="card">
                <div class="card-body px-0">

            <div class="table-responsive col-md-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Location</th>
                            <th>Guests</th>
                            <th>Phone Number</th>
                            <th>Email</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($booking->id); ?></td>
                                <td><?php echo e($booking->user->first_name); ?></td>
                                <td><?php echo e($booking->date); ?></td>
                                <td><?php echo e($booking->location); ?></td>
                                <td>₦<?php echo e(number_format($booking->amount_paid,2)); ?></td>
                                <td><?php echo e($booking->guests); ?></td>
                                <td><?php echo e($booking->phone_number); ?></td>
                                <td><?php echo e($booking->email); ?></td>
                                <td><?php echo e($booking->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($bookings->links()); ?>


                </div></div>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tour_api\resources\views/admin/bookings.blade.php ENDPATH**/ ?>