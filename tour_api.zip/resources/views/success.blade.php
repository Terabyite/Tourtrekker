<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Successful</title>
</head>
<body>
  <div style="text-align: center; padding: 50px;">
    <h1>Your payment was successful!</h1>
    <p>Kindly navigate to your bookings page</p>
  </div>
</body>
</html>
