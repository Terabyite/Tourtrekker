@extends('layouts.admin')
@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">

            <div class="card">
                <div class="card-body px-0">

            <div class="table-responsive col-md-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Amount Paid</th>
                            <th>Guests</th>
                            <th>Phone Number</th>
                            <th>Email</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($bookings as $booking)
                            <tr>
                                <td>{{ $booking->id }}</td>
                                <td>{{ $booking->user->first_name }}</td>
                                <td>{{ $booking->date }}</td>
                                <td>{{ $booking->location }}</td>
                                <td>₦{{ number_format($booking->amount_paid,2) }}</td>
                                <td>{{ $booking->guests }}</td>
                                <td>{{ $booking->phone_number }}</td>
                                <td>{{ $booking->email }}</td>
                                <td>{{ $booking->created_at }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="pagination mt-2">
                {{ $bookings->links() }}
            </div>


                </div></div>



        </div>
    </div>
@endsection
