@extends("layouts.admin")
@section("content")

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">


        <div class="card">
            <div class="card-body px-0">


        <div class="table-responsive col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Admin</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $user)
                        <tr>
                            <td>{{ $user->id }}</td>
                            <td>{{ $user->first_name }}</td>
                            <td>{{ $user->last_name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ $user->admin ? 'Yes' : 'No' }}</td>
                            <td>{{ $user->created_at }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

         {{ $users->links() }}

        </div>
    </div>
    </div>
</div>






@endsection
