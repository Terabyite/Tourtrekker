@extends("layouts.admin")
@section("content")

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="text-secondary">
                        Users
                    </div>
                    <div class="h4">
                        {{ number_format(\App\Models\User::count()) }}
                    </div>
                </div>
            </div>
        </div>


        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="text-secondary">
                        Bookings
                    </div>
                    <div class="h4">
                        {{ number_format(\App\Models\Booking::count()) }}
                    </div>
                </div>
            </div>
        </div>


      </div>
    </div>

</div>

@endsection

