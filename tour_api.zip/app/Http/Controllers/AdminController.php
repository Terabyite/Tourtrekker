<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{

    public function index()
    {
        if (Auth::check() && Auth::user()->admin) {
            return redirect(route('admin.dashboard'));
        } else {
            return redirect(route('admin.login_page'));
        }
    }


    function dashboard(){
        return view("admin.dashboard");
    }

    function users(){
        $users = User::latest()->paginate(15);
        return view("admin.users")->with("users",$users);
    }

    function bookings(){
        $bookings = Booking::where("paid",true)->latest()->paginate(15);
        return view("admin.bookings")->with("bookings",$bookings);
    }
    public function logout()
    {
        Auth::logout();
        return redirect(route('login'));
    }

}
