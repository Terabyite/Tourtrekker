<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function updateProfile(Request $request)
{
    $user = auth()->user();

    $request->validate([
        'first_name' => 'required|string',
        'last_name' => 'required|string',
        'gender' => 'required|in:male,female',
        'email' => 'required|string|email|unique:users,email,' . $user->id,
        'password' => 'nullable|string|min:8',
    ]);

    // Update user details
    $user->first_name = $request->first_name;
    $user->last_name = $request->last_name;
    $user->gender = $request->gender;
    $user->email = $request->email;

    // Update password if provided
    if ($request->filled('password')) {
        $user->password = Hash::make($request->password);
    }

    $user->save();

    return response()->json(['success' => true, 'message' => 'Profile updated successfully'], 200);
}


function show(){
    return response()->json(["user" => auth()->user() ],200);
}

}
