<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use SKAgarwal\GoogleApi\Exceptions\GooglePlacesApiException;
use SKAgarwal\GoogleApi\PlacesApi;

class PlacesController extends Controller
{

    function getNearbyPlaces(Request $request)
    {
        $request->validate([
            // 'latitude' => 'required|numeric',
            // 'longitude' => 'required|numeric',
            'search' => 'string|required'
        ]);


        $query = $request->search;

        // Construct the API endpoint URL
        $apiUrl = "https://api.content.tripadvisor.com/api/v1/location/search";
        $queryParams = [
            'searchQuery' => $query,
            'key' => env('TRIPADVISOR_KEY'),
            'category' => "attractions",
        ];

        // Make the API request
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Referer' => 'https://tourguide.tecrondigital.com.ng'
        ])->get($apiUrl, $queryParams);

        // Check if the request was successful
        if ($response->successful()) {
            // Get the response body
            $data = $response->json();

            // Return the response
            return response()->json($data);
        } else {
            // Handle the error
            $statusCode = $response->status();
            $errorMessage = $response->body();

            // For example: return an error response
            return response()->json(['error' => $errorMessage], $statusCode);
        }
    }

    function getPhotos(Request $request)
    {
        $request->validate([
            'place_id' => 'required|integer',
        ]);

        $id = $request->place_id;

        // Construct the API endpoint URL
        $apiUrl = "https://api.content.tripadvisor.com/api/v1/location/$id/photos";
        $queryParams = [
            'locationId' => $id,
            'key' => env('TRIPADVISOR_KEY'),
        ];

        // Make the API request
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Referer' => 'https://tourguide.tecrondigital.com.ng'
        ])->get($apiUrl, $queryParams);

        // Check if the request was successful
        if ($response->successful()) {
            // Get the response body
            $data = $response->json();

            // Return the response
            return response()->json($data);
        } else {
            // Handle the error
            $statusCode = $response->status();
            $errorMessage = $response->body();

            // For example: return an error response
            return response()->json(['error' => $errorMessage], $statusCode);
        }
    }

    function getDetails(Request $request)
    {
        $request->validate([
            'place_id' => 'required|integer',
        ]);

        $id = $request->place_id;

        // Construct the API endpoint URL
        $apiUrl = "https://api.content.tripadvisor.com/api/v1/location/$id/details";
        $queryParams = [
            'key' => env('TRIPADVISOR_KEY'),
        ];

        // Make the API request
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Referer' => 'https://tourguide.tecrondigital.com.ng'
        ])->get($apiUrl, $queryParams);

        // Check if the request was successful
        if ($response->successful()) {
            // Get the response body
            $data = $response->json();

            // Return the response
            return response()->json($data);
        } else {
            // Handle the error
            $statusCode = $response->status();
            $errorMessage = $response->body();

            // For example: return an error response
            return response()->json(['error' => $errorMessage], $statusCode);
        }
    }


}
