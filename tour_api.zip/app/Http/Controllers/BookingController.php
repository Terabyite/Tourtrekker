<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BookingController extends Controller
{
    public function index()
    {
        $bookings = Booking::where("user_id",auth()->user()->id)->where('paid',1)->get();
        return response()->json(['bookings' => $bookings], 200);
    }

    public function store(Request $request)
    {
        $request->validate([
            'location' => 'required|string',
            'date' => 'required|date',
            'guests' => 'required|integer',
            'name' => 'required|string',
            'phone_number' => 'required|string',
            'email' => 'required|email',
        ]);

        $booking = new Booking();
        $booking->location = $request->location;
        $booking->user_id = $request->user_id;
        $booking->date = Carbon::parse($request->date);
        $booking->guests = $request->guests;
        $booking->name = $request->name;
        $booking->phone_number = $request->phone_number;
        $booking->email = $request->email;
        $booking->user_id = auth()->user()->id;

        $booking->save();


        $url = $this->getPaystackPaymentUrl($booking->id);
        return response()->json(['url' => $url], 200);
    }


    public function verifyPayment(Request $request)
    {
        // Retrieve payment reference from the query parameters
        $paymentReference = $request->query('reference');

// Make request to Paystack to verify payment
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . env('PAYSTACK_KEY'),
            'Content-Type' => 'application/json',
        ])->get("https://api.paystack.co/transaction/verify/{$paymentReference}");

        // Check if the request was successful and payment was verified
        if ($response->successful() && $response['status'] === true) {

            $booking_id = $response['data']['metadata']['booking_id'];
            $booking = Booking::find($booking_id);


            $amountPaidToPaystack = $response['data']['amount'] / 100 ?? 0;

            $booking->paid = true;
            $booking->amount = $amountPaidToPaystack;
            $booking->save();
            // Create order

            return view('success');

        } else {
            return $response;
            // return Redirect::route('user.orders')->with('error', 'Payment failed. Please try again.');
        }
    }

    private function getPaystackPaymentUrl(Int $booking_id)
    {

        $booking = Booking::find($booking_id);
        $amount = 1000 * $booking->guests;

        $payload = [
            'email' => auth()->user()->email,
            'amount' => $amount * 100, // Amount in kobo
            'currency' => 'NGN',
            'callback_url' => route('verify-payment'),
            'metadata' => [
                'booking_id' => $booking->id
            ]
        ];

        // Make request to Paystack to initialize payment
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . env('PAYSTACK_KEY'),
            'Content-Type' => 'application/json',
        ])->post('https://api.paystack.co/transaction/initialize', $payload);

        if ($response->successful()) {
            return $response['data']['authorization_url'];
        } else {
            // Handle error response
            abort(500, 'Failed to initialize payment. Please try again later.');
        }
    }


    public function show($id)
    {
        $booking = Booking::findOrFail($id);
        return response()->json(['booking' => $booking], 200);
    }

    public function update(Request $request, $id)
    {
        $booking = Booking::findOrFail($id);

        $request->validate([
            'user_id' => 'required|exists:users,id',
            'date' => 'required|date',
            'location' => 'required|string',
            'user_location' => 'required|string',
        ]);

        $booking->update($request->all());

        return response()->json(['booking' => $booking], 200);
    }

    public function destroy($id)
    {
        $booking = Booking::findOrFail($id);
        $booking->delete();
        return response()->json(['message' => 'Booking deleted successfully'], 200);
    }
}
