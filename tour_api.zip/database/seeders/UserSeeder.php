<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new User();
        $user->first_name = "Innocent";
        $user->last_name = "Chijoke";
        $user->gender = "male";
        $user->email = "innocent@tourtrekker.com";
        $user->password = Hash::make("password");
        $user->admin = 1;
        $user->save();
    }
}
