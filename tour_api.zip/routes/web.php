<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\BookingController;
use App\Models\Booking;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();


Route::get("/fresh",function(){
    Artisan::call("migrate:fresh");
    Artisan::call("db:seed");
});

Route::get("cache-clear",function(){
    Artisan::call("cache:clear");
    Artisan::call("route:cache");
    });


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::group(["middleware" => ["admin"],'as' => "admin.","prefix" => "admin" ], function () {


    Route::get("/", [AdminController::class, "index"])->name("index");
    Route::get("/dashboard", [AdminController::class, "dashboard"])->name("dashboard");
    Route::get("/bookings", [AdminController::class, "bookings"])->name("bookings");
    Route::get("/users", [AdminController::class, "users"])->name("users");
    Route::get("/logout", [AdminController::class, "logout"])->name("logout");


});


Route::get("/verify-payment",[BookingController::class,"verifyPayment"])->name("verify-payment");
