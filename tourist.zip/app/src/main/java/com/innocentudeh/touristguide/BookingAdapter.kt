package com.innocentudeh.touristguide

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class BookingAdapter(var bookingList: List<Booking>,var context : Context) :
    RecyclerView.Adapter<BookingAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.booking_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val booking = bookingList[position]
        holder.bind(booking)
    }

    override fun getItemCount(): Int = bookingList.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Declare your view elements here (e.g., TextViews, ImageViews)
        private val placeName: TextView = itemView.findViewById<TextView>(R.id.name);
        private val date: TextView = itemView.findViewById<TextView>(R.id.date);


        fun bind(booking: Booking) {
                placeName.text = booking.placeName;
                date.text = booking.date;

            itemView.setOnClickListener {
                (context as BookingHistoryActivity).showBooking(booking);
            }
        }
    }
}
