package com.innocentudeh.touristguide

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class GuidelineActivity : AppCompatActivity() {

    private lateinit var backBtn : ImageButton;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guideline)

        backBtn = findViewById(R.id.back_btn);
        backBtn.setOnClickListener {
            finish();
        }

        supportActionBar?.elevation = 0F;
    }
}