package com.innocentudeh.touristguide

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView

class ReceiptActivity : AppCompatActivity() {

    private lateinit var booking : Booking;
    private lateinit var name : TextView;
    private lateinit var date : TextView;
    private lateinit var guests : TextView;
    private lateinit var amount : TextView;
    private lateinit var backBtn : Button;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receipt)

        backBtn = findViewById(R.id.back_btn);
        backBtn.setOnClickListener {
            finish();
        }
        name = findViewById(R.id.name);
        date = findViewById(R.id.date);
        guests = findViewById(R.id.guests);
        amount = findViewById(R.id.amount);

        booking = intent.getParcelableExtra<Booking>("booking")!!;


        name.text = booking.placeName;
        date.text = booking.date;
        guests.text = booking.guests.toString();
        amount.text = "₦"+booking.amount
    }


}