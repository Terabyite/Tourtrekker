package com.innocentudeh.touristguide

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

fun getCityFromLatLng(context: Context, lat: Double, lng: Double, callback: (String?) -> Unit) {
    val url = "https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lng&zoom=10&addressdetails=1"
    GlobalScope.launch(Dispatchers.IO) {
        try {
            val jsonString = getJsonStringFromUrl(url)
            val city = parseCityFromJson(jsonString)
            Log.d("LocationFind",city!!);
            callback(city)
        } catch (e: Exception) {
            Log.d("LocationFind",e.message!!)
            callback(null)
        }
    }
}

private suspend fun getJsonStringFromUrl(urlString: String): String {
    val url = URL(urlString)
    val connection = url.openConnection() as HttpURLConnection
    connection.connectTimeout = 5000
    connection.readTimeout = 5000
    val inputStream = connection.inputStream
    val bufferedReader = BufferedReader(InputStreamReader(inputStream))
    val stringBuilder = StringBuilder()
    var line: String?
    while (bufferedReader.readLine().also { line = it } != null) {
        stringBuilder.append(line).append("\n")
    }
    bufferedReader.close()
    return stringBuilder.toString()
}

private suspend fun parseCityFromJson(jsonString: String): String? {
    return try {
        val json = JSONObject(jsonString)
        val address = json.getJSONObject("address")
        address.optString("state") +", "+address.optString("country")
    } catch (e: Exception) {
        null
    }
}
