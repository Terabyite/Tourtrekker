package com.innocentudeh.touristguide

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class AuthActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        // Initially show the login fragment
        showLogin()
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.auth_frame, fragment)
            .commit()
    }

    fun showLogin() {
        replaceFragment(LoginFragment())
    }

    fun showRegister() {
        replaceFragment(RegisterFragment())
    }
}

