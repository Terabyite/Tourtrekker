package com.innocentudeh.touristguide

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import org.json.JSONObject

class PlacesAdapter(var places: List<Place>, val context: Context) :
    RecyclerView.Adapter<PlacesAdapter.PlaceViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlaceViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.location_item, parent, false)
        return PlaceViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlaceViewHolder, position: Int) {
        val place = places[position]
        holder.bind(place)
    }

    override fun getItemCount(): Int {
        return places.size
    }

    inner class PlaceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.name)
        private val distanceTextView: TextView = itemView.findViewById(R.id.distance)
        private val image: ImageView = itemView.findViewById(R.id.image)
        private var imageLoaded = false
        private  var imageString : String? = null;

        fun bind(place: Place) {
            nameTextView.text = place.name
            distanceTextView.text = place.address


            val requestUrl = Config.PHOTOS_URL
            val stringRequest = object : StringRequest(
                Method.POST, requestUrl,
                Response.Listener { response ->

                    val jsonResponse = JSONObject(response)
                    val data = jsonResponse.getJSONArray("data")

                    Log.d("ImageCheck","The image loaded for the place ${place.name} is $data");

                    if (data.length() > 0) {
                        //Update information here
                         imageString =
                            data.getJSONObject(0).getJSONObject("images").getJSONObject("large")
                                .getString(
                                    "url"
                                )



                        Glide.with(context)
                            .load(imageString)
                            .apply(
                                RequestOptions()
                                    .placeholder(R.drawable.placeholder) // Placeholder image
                                    .error(R.drawable.placeholder) // Error image in case of loading failure
                            )
                            .into(image)


                        imageLoaded = true
                        Log.d("ImageCheck","The image loaded for the place ${place.name} is $imageString");

                    }

                },
                Response.ErrorListener { error ->
                }
            ) {
                override fun getParams(): Map<String, String> {
                    val params = HashMap<String, String>()
                    params["place_id"] = place.id.toString()
                    return params
                }

                override fun getHeaders(): MutableMap<String, String> {

                    val authToken = (context as MainActivity).authToken
                    val headers = HashMap<String, String>()
                    headers["Accept"] = "application/json"
                    headers["Authorization"] = "Bearer $authToken"
                    return headers
                }
            }

            // Add the request to the RequestQueue.
            Volley.newRequestQueue(context).add(stringRequest)


            itemView.setOnClickListener {
                (this@PlacesAdapter.context as MainActivity).openDetail(place,imageString)
            }


        }
    }
}
