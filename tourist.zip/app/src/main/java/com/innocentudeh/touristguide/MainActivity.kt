package com.innocentudeh.touristguide

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.bottomappbar.BottomAppBar
import com.google.android.material.navigation.NavigationView
import org.json.JSONException
import org.json.JSONObject


class MainActivity : AppCompatActivity() {
    companion object {
        const val LOCATION_PERMISSION_REQUEST_CODE = 100
    }

    private lateinit var recyclerView: RecyclerView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var noDataView : TextView;
    private lateinit var navView: NavigationView
    private lateinit var swipeRefresh : SwipeRefreshLayout;
    private lateinit var loading : ProgressBar;
    var latitude : Double? = null;
    var longitude : Double? = null;
    private lateinit var fusedLocationClient : FusedLocationProviderClient;
    public lateinit var authToken : String;
    lateinit var toggle: ActionBarDrawerToggle;
    private lateinit var searchInput: EditText;
    private lateinit var searchBtn : ImageButton;
    private var query : String = "";
    private lateinit var bottomAppBar : BottomAppBar;
    private lateinit var userLocation : TextView;
    private lateinit var navBtn : ImageView;
    var currentUser:User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Reference layout elements

        drawerLayout = findViewById(R.id.drawer)
        navView = findViewById(R.id.sidebar)
        noDataView = findViewById(R.id.no_data_view);
        swipeRefresh = findViewById(R.id.swipe_refresh_layout);
        loading = findViewById(R.id.loading_bar);
        searchInput = findViewById(R.id.search_location)
        searchBtn = findViewById(R.id.search_btn);
        authToken = retrieveTokenFromSharedPreferences()!!;
        userLocation = findViewById(R.id.user_location);
        navBtn = findViewById(R.id.nav_btn);
        setupRecyclerView()
        // Set up SwipeRefreshLayout

        searchBtn.setOnClickListener {
            query = searchInput.text.toString();
            getPlaces();
        }
        swipeRefresh.setOnRefreshListener {
            refresh()
            swipeRefresh.isRefreshing = false
        }
        // Create Toolbar

        // Set a click listener for the hamburger menu icon
         toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.elevation = 0F;

        navBtn.setOnClickListener {
            // If the navigation drawer is not open then open it, if its already open then close it.
            if(!drawerLayout.isDrawerOpen(GravityCompat.START))
                drawerLayout.openDrawer(GravityCompat.START);
            else drawerLayout.closeDrawer(GravityCompat.END);
        }

        drawerLayout.addDrawerListener(toggle)
        toggle.isDrawerIndicatorEnabled = true;
        toggle.syncState()


        // Set listener for navigation item clicks
        navView.setNavigationItemSelectedListener { item ->
            // Handle menu item clicks
            when (item.itemId) {
                R.id.bookings -> {
                    val intent = Intent(this, BookingHistoryActivity::class.java);
                    startActivity(intent)
                }
                R.id.profile -> {
                    val intent = Intent(this,ProfileActivity::class.java);
                    startActivity(intent);
                }
                R.id.guidelines -> {
                    val intent = Intent(this,GuidelineActivity::class.java)
                    startActivity(intent);
                    return@setNavigationItemSelectedListener true
                }
                R.id.logout -> {
                    finish()
                    return@setNavigationItemSelectedListener true
                }
            }
            // Close the drawer after item selection
            drawerLayout.closeDrawer(navView)
            false
        }

        getLocation();
    }

    private fun getLocation(){
        // Initialize fused location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Check for location permission
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request location permission if not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }

        // Permission granted, get the last known location
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                // Got last known location. In some rare situations, this can be null.
                if (location != null) {
                     latitude = location.latitude
                     longitude = location.longitude

                    getCityFromLatLng(this@MainActivity, latitude!!,longitude!!) {
                        runOnUiThread {
                            if (it != null) {
                                Log.d("LocationTest",it)
                                userLocation.text = it;
                                query = it.toString()
                                searchInput.setText(it!!);
                                getPlaces()
                            };
                            else{
                                Toast.makeText(this@MainActivity,"Unable to retrieve location, please check your network settings",Toast.LENGTH_SHORT).show()
                            }

                        }

                    }
                    //Show prompt to make them search for a location.
                    noDataView.visibility = View.VISIBLE;

                } else {
                    Toast.makeText(
                        this,
                        "Unable to retrieve location. Please make sure location services are enabled.",
                        Toast.LENGTH_LONG
                    ).show()

                }
            }
    }

    private fun getPlaces() {

        //Validation if request should be made
        if(query.length < 2){
            Toast.makeText(this,"Please enter a location or destination to begin search",Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this,"Searching...",Toast.LENGTH_SHORT).show()

        val requestUrl = Config.GET_PLACES;
        showLoading()
        noDataView.visibility = View.GONE;
        val stringRequest = object : StringRequest(Method.POST, requestUrl,
            Response.Listener { response ->
                // Dismiss loading dialog
                hideLoading()
                noDataView.visibility = View.GONE;
                Log.d("MonitorPart", response.toString())
                val jsonResponse = JSONObject(response)
                val success = jsonResponse.getJSONArray("data")

                if (success.length() > 0) {
                //Process recycler view here
                    val placesList:  ArrayList<Place> = arrayListOf();

                    val data = jsonResponse.getJSONArray("data");

                    if(data.length() > 0){
                    for (i in 0 until data.length()) {
                        val item = data.getJSONObject(i)

                        //checking to see if it's a reasonable location
                        val address = item.getJSONObject("address_obj");
                        if(address.has("street1") && address.getString("street1").isNotEmpty()){
                        val itemName = item.getString("name");
                        val itemAddress = item.getJSONObject("address_obj").getString("street1");
                        val itemId = item.getInt("location_id")
                        val itemDistance = 1.04 //default

                        val place = Place(itemName,itemAddress,itemId,itemDistance);
                        placesList.add(place);
                        }

                    }
                    }
                    else{
                            noDataView.visibility = View.VISIBLE;
                    }

                    //Loop based on result


                    //Get the result from json request
                    loadAdapter(placesList);


                } else {
                    val message = jsonResponse.getString("message")
                    Toast.makeText(
                        this,
                        message,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            Response.ErrorListener { error ->
                // Dismiss loading dialog
                hideLoading()
                noDataView.visibility = View.VISIBLE;
                if (error.networkResponse != null) {
                    val statusCode = error.networkResponse.statusCode
                    val errorMessage = String(error.networkResponse.data)
                    Log.e("MonitorPart", "Error Response Code: $statusCode")
                    Log.e("MonitorPart", "Error Response: $errorMessage")

                    // Parse JSON error message
                    try {
                        val jsonResponse = JSONObject(errorMessage)
                        val message = jsonResponse.getString("message")
                        Toast.makeText(this, "An error occurred, please check your network connection", Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(this, "Server error", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("MonitorPart", "Error: ${error.message}")
                    Toast.makeText(this, "An error occurred, please check your network connection", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["latitude"] = latitude.toString()
                params["longitude"] = longitude.toString()
                params["search"] = searchInput.text.toString()
                return params
            }

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest)
    }

    private fun loadAdapter(placesList: ArrayList<Place>) {
        (recyclerView.adapter as PlacesAdapter).places = placesList;
        recyclerView.adapter!!.notifyDataSetChanged();
    }


    private fun showLoading(){
        loading.visibility = View.VISIBLE;
    }

    fun hideLoading(){
        loading.visibility = View.GONE;
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                showToast("Location permission granted")
                // Call getPlaces() function
                getPlaces()
            } else {
                // Permission denied
                showToast("Location permission denied")
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun setupRecyclerView() {
        recyclerView = findViewById(R.id.places_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        // Placeholder adapter, replace it with your actual adapter
        recyclerView.adapter = PlacesAdapter(emptyList(),this)
    }

    fun openDetail(place: Place, imageString: String?) {
        val intent = Intent(this,DetailActivity::class.java);
        intent.putExtra("place",place);
        intent.putExtra("image","$imageString")
        startActivity(intent);

    }


    private fun refresh(){
        setupRecyclerView()
        noDataView.visibility = View.GONE;
        getPlaces()
    }

    private fun retrieveTokenFromSharedPreferences(): String? {
        val sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(Config.TOKEN_KEY, null)
    }


    fun goToProfile(){
        val intent = Intent(this,ProfileActivity::class.java);
        startActivity(intent);
    }



    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (toggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item!!)
    }

}
