package com.innocentudeh.touristguide

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class ProfileActivity : AppCompatActivity() {

    private lateinit var backBtn : ImageButton;
    private lateinit var submitBtn : Button;
    private lateinit var firstNameInput : EditText;
    private lateinit var lastNameInput : EditText;
    private lateinit var emailInput : EditText;
    private lateinit var genderInput : EditText;
    private lateinit var passwordInput : EditText;
    public lateinit var authToken : String;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        backBtn = findViewById(R.id.back_btn)
        firstNameInput = findViewById(R.id.firstNameInput);
        lastNameInput = findViewById(R.id.lastNameInput);
        emailInput = findViewById(R.id.emailInput);
        authToken = retrieveTokenFromSharedPreferences()!!;
        genderInput = findViewById(R.id.genderInput);
        submitBtn = findViewById(R.id.submitBtn);

        backBtn.setOnClickListener {
            finish();
        }

        submitBtn.setOnClickListener {
            editProfile()
        }

        retrieveUser();

    }


    private fun retrieveUser(){
        val requestUrl = Config.GET_USER;
        val stringRequest = object : StringRequest(
            Method.GET, requestUrl,
            Response.Listener { response ->
                val jsonResponse = JSONObject(response)
                val userResponse = jsonResponse.getJSONObject("user")


                val user = User(
                    userResponse.getString("first_name"),
                    userResponse.getString("last_name"),
                    userResponse.getString("gender"),
                    userResponse.getString("email"),
                );

                firstNameInput.setText(user.firstName);
                lastNameInput.setText(user.lastName);
                emailInput.setText(user.email);
                emailInput.isEnabled = false;
                genderInput.setText(user.gender);

                Log.e("MonitorPart", "User: $user")
            },
            Response.ErrorListener { error ->
                Log.e("MonitorPart", "Error: ${error.message}")
                Toast.makeText(this, "An error occurred, please check your network connection", Toast.LENGTH_SHORT).show()

            }
        ) {

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }



        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest)
    }


    private fun editProfile(){

        if(firstNameInput.text.isEmpty() || lastNameInput.text.isEmpty() || genderInput.text.isEmpty()){
            Toast.makeText(this,"Please fill in the required fields",Toast.LENGTH_SHORT).show();
            return
        }

        val requestUrl = Config.UPDATE_PROFILE;
        val stringRequest = object : StringRequest(
            Method.POST, requestUrl,
            Response.Listener { response ->
                val jsonResponse = JSONObject(response)
                 if(jsonResponse.has("success")){
                     Toast.makeText(this,"Profile information updated successfully",Toast.LENGTH_SHORT).show();
                 }
                Log.e("MonitorPart", "Response: $response")
            },
            Response.ErrorListener { error ->
                Log.e("MonitorPart", "Error: ${error.message}")
                Toast.makeText(this, "An error occurred, please check your network connection", Toast.LENGTH_SHORT).show()

            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["first_name"] = firstNameInput.text.toString();
                params["last_name"] = lastNameInput.text.toString();
                params["gender"] = genderInput.text.toString();

                if(!(passwordInput.text.isEmpty())) {
                    params["password"] = passwordInput.text.toString();
                }

                return params
            }

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }



        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest)
    }

    private fun retrieveTokenFromSharedPreferences(): String? {
        val sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(Config.TOKEN_KEY, null)
    }


}