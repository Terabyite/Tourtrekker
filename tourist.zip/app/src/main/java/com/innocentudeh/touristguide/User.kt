package com.innocentudeh.touristguide

data class User (
    var firstName :String,
    var lastName : String,
    var gender : String,
    var email : String,
)