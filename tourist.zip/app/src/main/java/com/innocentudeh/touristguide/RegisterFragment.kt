package com.innocentudeh.touristguide

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject


class RegisterFragment : Fragment() {

    private lateinit var registerButton: Button
    private lateinit var goToLoginBtn: Button
    private lateinit var loadingDialog: Dialog
    private lateinit var firstNameField: EditText
    private lateinit var lastNameField: EditText
    private lateinit var genderField: AutoCompleteTextView

    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var activityContext: Context
    private lateinit var loading: ConstraintLayout;

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        registerButton = view.findViewById(R.id.registerBtn)
        firstNameField = view.findViewById(R.id.firstName)
        lastNameField = view.findViewById(R.id.lastName)
        genderField = view.findViewById(R.id.gender)
        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
            activityContext,
            android.R.layout.simple_dropdown_item_1line, arrayOf("Male","Female")
        );
        genderField.setAdapter(adapter)

        emailField = view.findViewById(R.id.email)
        passwordField = view.findViewById(R.id.password)
        goToLoginBtn = view.findViewById(R.id.goto_login)
        loading = view.findViewById(R.id.loading_bar);
        registerButton.setOnClickListener {
            val email = emailField.text.toString()
            val firstName = firstNameField.text.toString()
            val lastName = lastNameField.text.toString()
            val gender = genderField.text.toString()
            val password = passwordField.text.toString()

            if(email.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || gender.isEmpty() || password.isEmpty() ){
                Toast.makeText(activityContext,"Please fill in the required fields",Toast.LENGTH_SHORT).show()
            }
            else{
                if(!isValidEmail(email)){
                    Toast.makeText(activityContext,"Please enter a valid email address",Toast.LENGTH_SHORT).show()
                }
                else{
                    register(firstName,lastName,gender, email, password)
                }

            }

        }
        goToLoginBtn.setOnClickListener {
            (activityContext as AuthActivity).showLogin()
        }


    }
    private fun isValidEmail(email: String): Boolean {
        // Define a regex pattern to match a typical email address format
        val pattern = Regex("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")

        // Check if the input string matches the pattern
        return pattern.matches(email)
    }


    override fun onAttach(context: Context) {
        super.onAttach(context)
        activityContext = context
    }


    private fun register(firstName: String, lastName : String, gender:String, email: String, password: String) {
        // Show loading dialog
        showLoadingDialog()

        val requestUrl = Config.REGISTER_URL

        val stringRequest = object : StringRequest(Method.POST, requestUrl,
            Response.Listener { response ->
                // Dismiss loading dialog
                dismissLoadingDialog()

                Log.d("MonitorPart", response.toString())
                val jsonResponse = JSONObject(response)

                val success = jsonResponse.getBoolean("success")

                if (success) {
                    Toast.makeText(activityContext, "Registration successful", Toast.LENGTH_SHORT)
                        .show()
                    // Redirect to login activity after successful registration
                    (activityContext as AuthActivity).showLogin()
                } else {
                    val message = jsonResponse.getString("message")
                    Toast.makeText(
                        activityContext,
                        "Registration failed: $message",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            Response.ErrorListener { error ->
                // Dismiss loading dialog
                dismissLoadingDialog()
                if (error.networkResponse != null) {
                    val statusCode = error.networkResponse.statusCode
                    val errorMessage = String(error.networkResponse.data)
                    Log.e("MonitorPart", "Error Response Code: $statusCode")
                    Log.e("MonitorPart", "Error Response: $errorMessage")

                    // Parse JSON error message
                    try {
                        val jsonResponse = JSONObject(errorMessage)
                        val message = jsonResponse.getString("message")
                        Toast.makeText(context, "Error: $message", Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("MonitorPart", "Error: ${error.message}")
                    Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                params["first_name"] = firstName
                params["last_name"] = lastName
                params["gender"] = gender
                params["password"] = password
                return params
            }

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                return headers
            }
        }

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(activityContext).add(stringRequest)
    }

    private fun showLoadingDialog() {
        loading.visibility = View.VISIBLE;
    }

    private fun dismissLoadingDialog() {
        loading.visibility = View.GONE
    }

}