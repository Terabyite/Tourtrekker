package com.innocentudeh.touristguide

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject


class LoginFragment : Fragment() {

    private lateinit var loginButton: Button
    private lateinit var goToRegisterBtn: Button
    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var activityContext: Context
    private lateinit var loading: ConstraintLayout;


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loginButton = view.findViewById(R.id.buttonLogin)
        emailField = view.findViewById(R.id.email)
        passwordField = view.findViewById(R.id.password)
        goToRegisterBtn = view.findViewById(R.id.goto_signup)
        loading = view.findViewById(R.id.loading_bar);
        loginButton.setOnClickListener {
            val email = emailField.text.toString()
            val password = passwordField.text.toString()
            login(email, password)
        }
        goToRegisterBtn.setOnClickListener {
            (activityContext as AuthActivity).showRegister()
        }

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        activityContext = context
    }


    private fun login(email: String, password: String) {
        // Show loading dialog
        showLoadingDialog()

        val requestUrl = Config.LOGIN_URL

        val stringRequest = object : StringRequest(Method.POST, requestUrl,
            Response.Listener { response ->
                // Dismiss loading dialog
                dismissLoadingDialog()
                Log.d("MonitorPart", response.toString())
                val jsonResponse = JSONObject(response)

                val success = jsonResponse.getBoolean("success")

                if (success) {
                    val token = jsonResponse.getString("token")
                    saveTokenToSharedPreferences(token)
                    Toast.makeText(context, "Login successful", Toast.LENGTH_SHORT).show()

                    goToHome();
                } else {
                    val message = jsonResponse.getString("message")
                    Toast.makeText(context, "Login failed: $message", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                // Dismiss loading dialog
                dismissLoadingDialog()
                if (error.networkResponse != null) {
                    val statusCode = error.networkResponse.statusCode
                    val errorMessage = String(error.networkResponse.data)
                    Log.e("MonitorPart", "Error Response Code: $statusCode")
                    Log.e("MonitorPart", "Error Response: $errorMessage")

                    // Parse JSON error message
                    try {
                        val jsonResponse = JSONObject(errorMessage)
                        val message = jsonResponse.getString("message")
                        Toast.makeText(context, "Error: $message", Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("MonitorPart", "Error: ${error.message}")
                    Toast.makeText(context, "Error: A network error occurred", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["email"] = email
                params["password"] = password
                return params
            }


        }

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(activityContext).add(stringRequest)
    }

    private fun showLoadingDialog() {
   loading.visibility = View.VISIBLE;
    }

    private fun dismissLoadingDialog() {
    loading.visibility = View.GONE
    }

    private fun saveTokenToSharedPreferences(token: String) {
        val sharedPreferences =
            activityContext.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(Config.TOKEN_KEY, token)
        editor.apply()
    }

    fun goToHome(){
        val intent = Intent(activityContext,MainActivity::class.java);
        startActivity(intent);
        (activityContext  as AuthActivity).finish();

    }


}