package com.innocentudeh.touristguide

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel
import org.json.JSONException
import org.json.JSONObject

class DetailActivity : AppCompatActivity() {

    private lateinit var bookBtn : Button;
    private lateinit var placeName : TextView;
    private lateinit var placeDescription : TextView;
    private lateinit var placeLocation : TextView;
    private lateinit var placeRating : RatingBar;
    private lateinit var placeImage : ImageView
    private lateinit var loading : ConstraintLayout;
    private lateinit var authToken : String;
    private lateinit var imageList : ArrayList<SlideModel>
    private lateinit var imageSlider : ImageSlider;
    private lateinit var backBtn : ImageButton;
    private lateinit var ratingText : TextView;

    private lateinit var place : Place;
    private var image : String? = null;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        backBtn = findViewById(R.id.back_btn)
        backBtn.setOnClickListener {
            finish();
        }
        val receivedIntent = intent
        // Get the Place object (cast it to Place)
        place = receivedIntent.getParcelableExtra<Place>("place")!!
        image = receivedIntent.getStringExtra("image");


        supportActionBar?.elevation = 0F;

        placeName = findViewById(R.id.place_name);
        placeDescription = findViewById(R.id.place_description);
        placeLocation = findViewById(R.id.place_location);
        loading = findViewById(R.id.loading);
        imageSlider = findViewById<ImageSlider>(R.id.image_slider)
        imageSlider.stopSliding()
        ratingText = findViewById(R.id.ratingText)
        imageSlider.setImageList(arrayListOf(), ScaleTypes.CENTER_CROP) // for all images
        authToken = retrieveTokenFromSharedPreferences()!!


        placeName.text = place.name;
        placeLocation.text = place.address;
        placeDescription.text = "Loading description..."

        //Get the first image found


        if(!image.isNullOrBlank()){
            imageList = arrayListOf()
            imageList.add(SlideModel(image,""))
            imageSlider.setImageList(imageList);
        }



        getPhotos();
        getDetails()

        bookBtn = findViewById(R.id.book_button);
        bookBtn.setOnClickListener {
            val intent = Intent(this,BookingActivity::class.java);
            intent.putExtra("name", place.name);
            intent.putExtra("address",place.address)
            intent.putExtra("image",image);
            startActivity(intent);
        }
    }


    private fun getPhotos(){
//This functions get the images of the location

        val requestUrl = Config.PHOTOS_URL;
showLoading()
        val stringRequest = object : StringRequest(
            Method.POST, requestUrl,
            Response.Listener { response ->
                // Dismiss loading dialog
                hideLoading()
                Log.d("MonitorPart", response.toString())
                val jsonResponse = JSONObject(response)
                val data = jsonResponse.getJSONArray("data");

                if(data.length() > 0){
                    //Update information here
                    //val image : String? = data.getJSONObject(0).getJSONObject("images").getJSONObject("large").getString(
                  //      "url"
                    //);

                    //Loop images
                    imageList = arrayListOf() // Create image list

                    for (i in 0 until data.length()) {
                        val url = data.getJSONObject(i).getJSONObject("images").getJSONObject("large").getString(
                            "url"
                        );
                        imageList.add(SlideModel(url, ""))
                    }
                    imageSlider.setImageList(imageList)
                    imageSlider.startSliding()
                    imageSlider.setImageList(imageList, ScaleTypes.CENTER_CROP) // for all images

                } else {
                    val message = "An error occurred getting the images";
                    Toast.makeText(
                        this,
                        message,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            Response.ErrorListener { error ->
                // Dismiss loading dialog
                hideLoading()
                if (error.networkResponse != null) {
                    val statusCode = error.networkResponse.statusCode
                    val errorMessage = String(error.networkResponse.data)
                    Log.e("MonitorPart", "Error Response Code: $statusCode")
                    Log.e("MonitorPart", "Error Response: $errorMessage")

                    // Parse JSON error message
                    try {
                        val jsonResponse = JSONObject(errorMessage)
                        val message = jsonResponse.getString("message")
                        Toast.makeText(this, "Error: $message", Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(this, "Server error", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("MonitorPart", "Error: ${error.message}")
                    Toast.makeText(this, "An error occurred", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["place_id"] = place.id.toString()
                return params
            }

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest)
    }


    private fun getDetails(){
//This functions get the images of the location

        val requestUrl = Config.DETAILS;
        showLoading()
        val stringRequest = object : StringRequest(
            Method.POST, requestUrl,
            Response.Listener { response ->
                // Dismiss loading dialog
                hideLoading()
                Log.d("MonitorPart", response.toString())
                val data = JSONObject(response)

                var description = "Loading..."

                description = if(data.has("description")){
                    data.getString("description");
                } else{
                    "";
                }

                var rating = 3.0;

                rating = if(data.has("rating")){
                    data.getDouble("rating");
                } else{
                    3.0;
                }



                    //Update information here

                val address = data.getJSONObject("address_obj").getString("address_string");
                val name = data.getString("name");

                //Set views
                placeName.text = name;
                placeLocation.text = address;
                placeDescription.text = description;
                ratingText.text = rating.toString()

            },
            Response.ErrorListener { error ->
                // Dismiss loading dialog
                hideLoading()
                if (error.networkResponse != null) {
                    val statusCode = error.networkResponse.statusCode
                    val errorMessage = String(error.networkResponse.data)
                    Log.e("MonitorPart", "Error Response Code: $statusCode")
                    Log.e("MonitorPart", "Error Response: $errorMessage")

                    // Parse JSON error message
                    try {
                        val jsonResponse = JSONObject(errorMessage)
                        val message = jsonResponse.getString("message")
                        Toast.makeText(this, "Error: $message", Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(this, "Server error", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("MonitorPart", "Error: ${error.message}")
                    Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["place_id"] = place.id.toString()
                return params
            }

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest)
    }
    private fun showLoading(){
        loading.visibility = View.VISIBLE;
    }

    fun hideLoading(){
        loading.visibility = View.GONE;
    }



    private fun retrieveTokenFromSharedPreferences(): String? {
        val sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(Config.TOKEN_KEY, null)
    }


}