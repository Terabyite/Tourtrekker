package com.innocentudeh.touristguide

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity


class CheckoutActivity : AppCompatActivity() {

    private lateinit var url : String;
    private lateinit var webView : WebView;
    private lateinit var backBtn : ImageButton;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)
        url = intent.getStringExtra("url")!!;

        webView = findViewById(R.id.web_view)
        webView.settings.javaScriptEnabled = true;
        webView.settings.pluginState = WebSettings.PluginState.ON;
        webView.loadUrl(url);

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return false // then it is not handled by default action
            }
        }

        backBtn = findViewById(R.id.back_btn);
        backBtn.setOnClickListener {
            finish();
        }


    }
}