package com.innocentudeh.touristguide

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import org.json.JSONException
import org.json.JSONObject
import java.util.Calendar


class BookingActivity : AppCompatActivity() {

    private lateinit var editTextPlaceName: EditText
    private lateinit var editTextComments: EditText
    private lateinit var buttonSubmit: Button
    private lateinit var receivedIntent : Intent
    private lateinit var authToken : String
    private lateinit var backBtn : Button
    private lateinit var placeName : TextView
    private lateinit var placeLocation : TextView
    private lateinit var placeImage : ImageView
    private lateinit var longAddress : String

    //Fields

    private lateinit var dateInput : EditText
    private lateinit var guestsInput : EditText
    private lateinit var nameInput : EditText
    private lateinit var phoneInput : EditText
    private lateinit var emailInput : EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)
        buttonSubmit = findViewById(R.id.buttonSubmit)
        authToken = retrieveTokenFromSharedPreferences()!!
        backBtn = findViewById(R.id.backBtn)
        backBtn.setOnClickListener {
            finish()
        }

        placeName = findViewById(R.id.place_name)
        placeLocation = findViewById(R.id.place_location)
        placeImage = findViewById(R.id.place_image)

        dateInput = findViewById(R.id.dateInput)

        dateInput.setOnClickListener { // Get current date
            val calendar: Calendar = Calendar.getInstance()
            val year: Int = calendar.get(Calendar.YEAR)
            val month: Int = calendar.get(Calendar.MONTH)
            val day: Int = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                this@BookingActivity,
                { _, year, monthOfYear, dayOfMonth -> // Format and update the EditText with selected date
                    val date = year.toString() + "-" + (monthOfYear + 1) + "-" + dayOfMonth
                    dateInput.setText(date)
                }, year, month, day
            )

            datePickerDialog.show()
        }
        nameInput = findViewById(R.id.nameInput)
        phoneInput = findViewById(R.id.phoneInput)
        emailInput = findViewById(R.id.emailInput)
        guestsInput = findViewById(R.id.guestsInput)

        supportActionBar?.elevation = 0F
        receivedIntent = intent
        val name = receivedIntent.getStringExtra("name")
        val image = receivedIntent.getStringExtra("image")
        val address = receivedIntent.getStringExtra("address")

        placeName.text = name
        placeLocation.text = address
        Glide.with(this)
            .load(image)
            .apply(
                RequestOptions()
                    .placeholder(R.drawable.placeholder) // Placeholder image
                    .error(R.drawable.placeholder) // Error image in case of loading failure
            )
            .into(placeImage)


        buttonSubmit.setOnClickListener {
            sendDataToServer()
        }
    }
    fun isValidPhoneNumber(phoneNumber: String): Boolean {
        // Define a regex pattern to match a typical phone number format
        val pattern = Regex("^\\+(?:[0-9] ?){6,14}[0-9]$")

        // Check if the input string matches the pattern
        return pattern.matches(phoneNumber)
    }


    private fun sendDataToServer() {

        if(dateInput.text.isEmpty() || guestsInput.text.isEmpty() || nameInput.text.isEmpty() || phoneInput.text.isEmpty() || emailInput.text.isEmpty()){
            Toast.makeText(this,"Please fill in the required fields",Toast.LENGTH_SHORT).show()
            return
        }

        if(!isValidPhoneNumber(phoneInput.text.toString())){
            Toast.makeText(this,"Please enter a valid phone number",Toast.LENGTH_SHORT).show()
            return
        }


        buttonSubmit.text = "Sending..."

        // Instantiate the RequestQueue.
        val queue: RequestQueue = Volley.newRequestQueue(this)

        val url = Config.BOOKING_URL
        // Request a string response from the provided URL.
        val stringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener<String> { response ->
                try {
                    val jsonObject = JSONObject(response)
                    if (jsonObject.has("url")) {
                        val url = jsonObject.getString("url")
                        openWebView(url)

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Toast.makeText(this@BookingActivity, "Error: " + e.message, Toast.LENGTH_SHORT).show()
                }

                buttonSubmit.text = "Confirm"
            },
            Response.ErrorListener { error ->
                Toast.makeText(this@BookingActivity, "Error: " + error.message, Toast.LENGTH_SHORT).show()
                buttonSubmit.text = "Confirm"
            }) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["location"] = placeName.text.toString()
                params["date"] = dateInput.text.toString()
                params["guests"] = guestsInput.text.toString()
                params["name"] = nameInput.text.toString()
                params["phone_number"] = phoneInput.text.toString()
                params["email"] = emailInput.text.toString()
                return params
            }
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }

        // Add the request to the RequestQueue.
        queue.add(stringRequest)
    }


    fun openWebView(url : String){
        val intent = Intent(this,CheckoutActivity::class.java)
        intent.putExtra("url",url)

        startActivity(intent)

    }

    private fun retrieveTokenFromSharedPreferences(): String? {
        val sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(Config.TOKEN_KEY, null)
    }


}