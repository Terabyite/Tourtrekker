package com.innocentudeh.touristguide

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.navigation.NavigationView
import org.json.JSONException
import org.json.JSONObject

class BookingHistoryActivity : AppCompatActivity() {

    private lateinit var bookingsRecyclerView : RecyclerView
    private lateinit var backBtn : ImageButton;
    private lateinit var noDataView : TextView;
    private lateinit var navView: NavigationView
    private lateinit var swipeRefresh : SwipeRefreshLayout;
    private lateinit var loading : ProgressBar;
    private lateinit var recyclerView : RecyclerView;
    public lateinit var authToken : String;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking_history)
        backBtn = findViewById(R.id.back_btn);
        swipeRefresh = findViewById(R.id.swipe_refresh_layout);
        loading = findViewById(R.id.loading_bar);
        noDataView = findViewById(R.id.no_data_view);
        authToken = retrieveTokenFromSharedPreferences()!!;
        recyclerView = findViewById(R.id.bookings);

        backBtn = findViewById(R.id.back_btn)
        backBtn.setOnClickListener {
            finish();
        }
        setupRecyclerView();
        getBookings()

        swipeRefresh.setOnRefreshListener {
            getBookings();
            swipeRefresh.isRefreshing = false;
        }
    }

    private fun getBookings() {

        val requestUrl = Config.BOOKINGS;
        showLoading()
        noDataView.visibility = View.GONE;
        val stringRequest = object : StringRequest(
            Method.GET, requestUrl,
            Response.Listener { response ->
                // Dismiss loading dialog
                hideLoading()
                noDataView.visibility = View.GONE;
                Log.d("MonitorPart", response.toString())
                val jsonResponse = JSONObject(response)
                val data = jsonResponse.getJSONArray("bookings")
                    val bookingList:  ArrayList<Booking> = arrayListOf();

                    if(data.length() > 0){
                        for (i in 0 until data.length()) {
                            val bookingEntry  = data.getJSONObject(i)

                            val booking = Booking(
                                bookingEntry.getString("location"),
                                bookingEntry.getDouble("amount"),
                            bookingEntry.getString("phone_number"),
                            bookingEntry.getString("date"),
                            bookingEntry.getInt("guests"),
                            );

                            bookingList.add(booking);
                            loadAdapter(bookingList);


                        }
                    }
                    else{
                        noDataView.visibility = View.VISIBLE;
                    }


            },
            Response.ErrorListener { error ->
                // Dismiss loading dialog
                hideLoading()
                noDataView.visibility = View.VISIBLE;
                if (error.networkResponse != null) {
                    val statusCode = error.networkResponse.statusCode
                    val errorMessage = String(error.networkResponse.data)
                    Log.e("MonitorPart", "Error Response Code: $statusCode")
                    Log.e("MonitorPart", "Error Response: $errorMessage")

                    // Parse JSON error message
                    try {
                        val jsonResponse = JSONObject(errorMessage)
                        val message = jsonResponse.getString("message")
                        Toast.makeText(this, "An error occurred, please check your network connection", Toast.LENGTH_SHORT).show()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Toast.makeText(this, "Server error", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("MonitorPart", "Error: ${error.message}")
                    Toast.makeText(this, "An error occurred, please check your network connection", Toast.LENGTH_SHORT).show()
                }
            }
        ) {

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Accept"] = "application/json"
                headers["Authorization"] = "Bearer $authToken"
                return headers
            }
        }

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest)
    }

    private fun loadAdapter(bookingList: ArrayList<Booking>) {
        (recyclerView.adapter as BookingAdapter).bookingList = bookingList;
        recyclerView.adapter!!.notifyDataSetChanged();
    }


    private fun showLoading(){
        loading.visibility = View.VISIBLE;
    }

    fun hideLoading(){
        loading.visibility = View.GONE;
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = BookingAdapter(emptyList(),this)
    }

    private fun retrieveTokenFromSharedPreferences(): String? {
        val sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(Config.TOKEN_KEY, null)
    }


    fun showBooking(booking: Booking) {
        var intent = Intent(this,ReceiptActivity::class.java);
        intent.putExtra("booking",booking);

        startActivity(intent);


    }


}