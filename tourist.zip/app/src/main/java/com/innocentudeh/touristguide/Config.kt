package com.innocentudeh.touristguide



object Config {
    const val SHARED_PREF_NAME = "auth_info"
    const val TOKEN_KEY = "token"
    private const val BASE_URL = "https://tourguide.tecrondigital.com.ng/api"
    const val LOGIN_URL = "$BASE_URL/login";
    const val REGISTER_URL = "$BASE_URL/register";
    const val GET_PLACES = "$BASE_URL/nearby-places";
    const val BOOKING_URL = "$BASE_URL/bookings";
    const val PHOTOS_URL = "$BASE_URL/photos";
    const val DETAILS = "$BASE_URL/details";
    const val BOOKINGS =  "$BASE_URL/bookings";
    const val GET_USER =  "$BASE_URL/user";
    const val UPDATE_PROFILE =  "$BASE_URL/update-profile";

}
